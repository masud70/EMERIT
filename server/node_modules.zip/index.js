const express = require('express');
var bodyParser = require('body-parser');
const app = express();
const http = require('http');
const server = http.createServer(app);
// const { Server } = require("socket.io");
// const io = new Server(server);
const io = require('socket.io')(server, {
    cors: {
      origin: "https://192.168.0.109:5000",
      methods: ["GET", "POST"]
    }
  });
const port = 3000;


app.use(bodyParser.urlencoded({extended: true}))
app.use(express.json())

app.get('/', (req, res) => {
  res.send('Hello!!');
});

io.on('connection', (socket) => {
  console.log('A user connected');

  socket.on('send_message',(data)=>{
    console.log("received message in server side",data)
    io.emit('received_message', "Data from server.")
  })

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
  
});

server.listen(port, () => {
  console.log( `Server running at http://localhost:${port}/`);
});